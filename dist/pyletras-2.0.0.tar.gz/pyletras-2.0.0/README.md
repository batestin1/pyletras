
<h1 align="center">
<img src="https://img.shields.io/static/v1?label=PYLETRAS%20POR&message=Bates&color=7159c1&style=flat-square&logo=ghost"/>
<h3> <p align="center">PYLETRAS </p> </h3>
<h3> <p align="center"> ================= </p> </h3>

>> <h3> Resume </h3>

<p> Este projeto é apenas uma leve versao de API do site <b> www.letras.mus.br </b>, um dos maiores sites com repositorio de letras de música do Brasil. Nesta api, você insere o nome da banda(ou autor) e o nome da canção que deseja consultar e ela te retorna um arquivo <b> txt </b> contendo o resultado da sua busca.  </p>

>> <h3> How install </h3>

```
pip install pyletras
```

>> <h3> How Works </h3>

<p> open a new script ".py" and insert the command below: </p>

```
from pyletras import *

pyletras()
```
    